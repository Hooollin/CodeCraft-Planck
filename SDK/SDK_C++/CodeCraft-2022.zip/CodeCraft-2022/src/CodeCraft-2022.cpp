#include "distributor.h"

int main() {

  Distributor distributor(1);
  distributor.DayDistribute();
  return 0;
}
