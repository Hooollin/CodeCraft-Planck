#include "distributor.h"
#include "test.h"
int main() {
 Test test(2);
 test.TestAll();

  // Distributor distributor(1);
  // distributor.DayDistribute();
  return 0;
}
