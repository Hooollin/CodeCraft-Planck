#include "test.h"
#include "distributor.h"

int main() {
//  Test test_example(3);
//  test_example.TestAll();

  Distributor distributor(1);
  distributor.DayDistribute();
  return 0;
}
